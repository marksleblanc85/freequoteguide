(function(a,h,y){var w="function",v="password",j="maxLength",n="type",b="",c=true,u="placeholder",i=false,t="watermark",g=t,f="watermarkClass",q="watermarkFocus",l="watermarkSubmit",o="watermarkMaxLength",e="watermarkPassword",d="watermarkText",k=/\r/g,s="input:data("+g+"),textarea:data("+g+")",m="input:text,input:password,input[type=search],input:not([type]),textarea",p=["Page_ClientValidate"],r=i,x=u in document.createElement("input");a.watermark=a.watermark||{version:"3.1.3",runOnce:c,options:{className:t,useNative:c,hideBeforeUnload:c},hide:function(b){a(b).filter(s).each(function(){a.watermark._hide(a(this))})},_hide:function(a,r){var p=a[0],q=(p.value||b).replace(k,b),l=a.data(d)||b,m=a.data(o)||0,i=a.data(f);if(l.length&&q==l){p.value=b;if(a.data(e))if((a.attr(n)||b)==="text"){var g=a.data(e)||[],c=a.parent()||[];if(g.length&&c.length){c[0].removeChild(a[0]);c[0].appendChild(g[0]);a=g}}if(m){a.attr(j,m);a.removeData(o)}if(r){a.attr("autocomplete","off");h.setTimeout(function(){a.select()},1)}}i&&a.removeClass(i)},show:function(b){a(b).filter(s).each(function(){a.watermark._show(a(this))})},_show:function(g){var p=g[0],u=(p.value||b).replace(k,b),h=g.data(d)||b,s=g.attr(n)||b,t=g.data(f);if((u.length==0||u==h)&&!g.data(q)){r=c;if(g.data(e))if(s===v){var m=g.data(e)||[],l=g.parent()||[];if(m.length&&l.length){l[0].removeChild(g[0]);l[0].appendChild(m[0]);g=m;g.attr(j,h.length);p=g[0]}}if(s==="text"||s==="search"){var i=g.attr(j)||0;if(i>0&&h.length>i){g.data(o,i);g.attr(j,h.length)}}t&&g.addClass(t);p.value=h}else a.watermark._hide(g)},hideAll:function(){if(r){a.watermark.hide(m);r=i}},showAll:function(){a.watermark.show(m)}};a.fn.watermark=a.fn.watermark||function(p,o){var t="string";if(!this.length)return this;var s=i,r=typeof p===t;if(r)p=p.replace(k,b);if(typeof o==="object"){s=typeof o.className===t;o=a.extend({},a.watermark.options,o)}else if(typeof o===t){s=c;o=a.extend({},a.watermark.options,{className:o})}else o=a.watermark.options;if(typeof o.useNative!==w)o.useNative=o.useNative?function(){return c}:function(){return i};return this.each(function(){var B="dragleave",A="dragenter",z=this,i=a(z);if(!i.is(m))return;if(i.data(g)){if(r||s){a.watermark._hide(i);r&&i.data(d,p);s&&i.data(f,o.className)}}else{if(x&&o.useNative.call(z,i)&&(i.attr("tagName")||b)!=="TEXTAREA"){r&&i.attr(u,p);return}i.data(d,r?p:b);i.data(f,o.className);i.data(g,1);if((i.attr(n)||b)===v){var C=i.wrap("<span>").parent(),t=a(C.html().replace(/type=["']?password["']?/i,'type="text"'));t.data(d,i.data(d));t.data(f,i.data(f));t.data(g,1);t.attr(j,p.length);t.focus(function(){a.watermark._hide(t,c)}).bind(A,function(){a.watermark._hide(t)}).bind("dragend",function(){h.setTimeout(function(){t.blur()},1)});i.blur(function(){a.watermark._show(i)}).bind(B,function(){a.watermark._show(i)});t.data(e,i);i.data(e,t)}else i.focus(function(){i.data(q,1);a.watermark._hide(i,c)}).blur(function(){i.data(q,0);a.watermark._show(i)}).bind(A,function(){a.watermark._hide(i)}).bind(B,function(){a.watermark._show(i)}).bind("dragend",function(){h.setTimeout(function(){a.watermark._show(i)},1)}).bind("drop",function(e){var c=i[0],a=e.originalEvent.dataTransfer.getData("Text");if((c.value||b).replace(k,b).replace(a,b)===i.data(d))c.value=a;i.focus()});if(z.form){var w=z.form,y=a(w);if(!y.data(l)){y.submit(a.watermark.hideAll);if(w.submit){y.data(l,w.submit);w.submit=function(c,b){return function(){var d=b.data(l);a.watermark.hideAll();if(d.apply)d.apply(c,Array.prototype.slice.call(arguments));else d()}}(w,y)}else{y.data(l,1);w.submit=function(b){return function(){a.watermark.hideAll();delete b.submit;b.submit()}}(w)}}}}a.watermark._show(i)})};if(a.watermark.runOnce){a.watermark.runOnce=i;a.extend(a.expr[":"],{data:function(c,d,b){return!!a.data(c,b[3])}});(function(c){a.fn.val=function(){var e=this;if(!e.length)return arguments.length?e:y;if(!arguments.length)if(e.data(g)){var f=(e[0].value||b).replace(k,b);return f===(e.data(d)||b)?b:f}else return c.apply(e,arguments);else{c.apply(e,arguments);a.watermark.show(e);return e}}})(a.fn.val);p.length&&a(function(){for(var b,c,d=p.length-1;d>=0;d--){b=p[d];c=h[b];if(typeof c===w)h[b]=function(b){return function(){a.watermark.hideAll();return b.apply(null,Array.prototype.slice.call(arguments))}}(c)}});a(h).bind("beforeunload",function(){a.watermark.options.hideBeforeUnload&&a.watermark.hideAll()})}})(jQuery,window);
$(function () {
	$('.submit').click(function(){
		$('form.formhandler').submit();
	});
	$('input[type="text"]').add('textarea').each(function(){
		$(this).watermark($(this).attr('placeholder'));
	});
	$('.submit').attr('disabled', false);
	$('form.formhandler').submit(function (e) {
		var email_error = "Please enter a valid email address.";
		var req_field_error = "Please fill in the required fields.";
		var valid = true;
		var emailvalid = true;
		var form = $(this);
		var post_url = $(this).attr('action') + '?ajax=1';
		var postedForm = $(this);
		var post_data = $(this).serialize();

		$('.error').blur(function () {
			if ($(this).val() != "") {
				$(this).removeClass('error');
			}
		});
		$(this).find('.required').removeClass('error');
		$(this).find('.required').each(function () {
			var value = $(this).val();
			if (value == '') {
				$(this).addClass('error');
				valid = false;
					}
			else if ($(this).hasClass('email')) {
				if (!isValidEmailAddress(value)) {
						$(this).addClass('error');
						valid = false;
					emailvalid = false;
				}
			}
		});
		if (valid) {
			$(this).find('.feedback').hide().html('');
			$(this).find('.submit').attr('disabled', true).addClass('disabled');
			$('body').css('cursor', 'wait');
			if ($.browser.msie == true) {
				//$(this).submit();
				$('.submit').attr('disabled', false);
				$('body').add('.submit').css('cursor', 'default');
			} else {
				e.preventDefault();
				$.ajax({
					type: 'POST',
					url: post_url,
					data: post_data,
					dataType: 'json',
					success: function (result) {
						$('body').css('cursor', 'default');
						var r = eval(result)[0];
						postedForm.find('.feedback').show().removeClass('alert-error').addClass('alert-success').html('<h4>Thanks</h4><br/>Your submission was sent successfully.').css('display', 'block').focus();
						postedForm.find('.submit').attr('disabled', false).removeClass('disabled');
					},
					error: function () {
						$('body').css('cursor', 'default');
						postedForm.find('.feedback').show().addClass('alert-error').html().css('display', 'block').focus();
						postedForm.find('.submit').attr('disabled', false).removeClass('disabled');
					},
					complete: function () {
						$('body').css('cursor', 'default');
						postedForm.find('.submit').attr('disabled', false).removeClass('disabled');
					}
				});
			}
		} else if (emailvalid == false) {
			e.preventDefault();
			$('body').css('cursor', 'default');
			$(this).find('.feedback').hide().html('');
			$(this).find('.feedback').show().addClass('alert-error').html('<h4>Error.</h4><p>' + email_error + '</p>').css('display', 'block').focus();
		} else {
			e.preventDefault();
			$('body').css('cursor', 'default');
			$(this).find('.feedback').html('');
			$(this).find('.feedback').show().addClass('alert-error').html('<h4>Error.</h4><p>' + req_field_error + '</p>').css('display', 'block').focus();
		}
		if ($('.email').attr('placeholder')) {
			$('input[type="text"]').add('textarea').each(function () {
				$(this).watermark($(this).attr('placeholder'));
			});
		}
	});
});